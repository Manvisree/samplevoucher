package com.va.voucher_request.contoller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.va.voucher_request.exceptions.NotFoundException;
import com.va.voucher_request.exceptions.ScoreNotValidException;
import com.va.voucher_request.model.VoucherRequest;
import com.va.voucher_request.model.VoucherRequestDto;
import com.va.voucher_request.service.VoucherReqServiceImpl;

@RestController
@RequestMapping("/requests")
@CrossOrigin("*")
public class VoucherReqController {
	
	@Autowired
	private VoucherReqServiceImpl vservice;
	
	@PostMapping("/voucher")
    public VoucherRequest requestVoucher(@RequestBody VoucherRequestDto request) throws ScoreNotValidException {
		return vservice.requestVoucher(request);
    }

    @GetMapping("/{candidateEmail}")
    public List<VoucherRequest> getAllVouchersByCandidateEmail(@PathVariable String candidateEmail) throws NotFoundException {
        return vservice.getAllVouchersByCandidateEmail(candidateEmail);
    }
    
    @PutMapping("/updateExamDate/{voucherCode}/{newExamDate}")
	public VoucherRequest updateExamDate(@PathVariable String voucherCode,@PathVariable LocalDate newExamDate) throws NotFoundException {
    	 return vservice.updateExamDate(voucherCode, newExamDate);
    }
		

    @PutMapping("/{voucherCode}/{newExamResult}")
    public ResponseEntity<VoucherRequest> updateResultStatus( @PathVariable String voucherCode, @PathVariable String newExamResult) {
        try {
            VoucherRequest updatedVoucherRequest = vservice.updateExamResult(voucherCode, newExamResult);
            return ResponseEntity.ok(updatedVoucherRequest);
        } catch (NotFoundException e) {
            return ResponseEntity.notFound().build();

        }

    }

}
