package com.va.voucher_request.exceptions;

public class ScoreNotValidException extends Exception{
	public ScoreNotValidException(String msg) {
		super(msg);
	}

}
