package com.va.voucher_request.service;

import java.time.LocalDate;
import java.util.List;

import com.va.voucher_request.exceptions.NotFoundException;
import com.va.voucher_request.exceptions.ScoreNotValidException;
import com.va.voucher_request.model.VoucherRequest;
import com.va.voucher_request.model.VoucherRequestDto;

public interface VoucherReqService {
	
	VoucherRequest requestVoucher(VoucherRequestDto request) throws ScoreNotValidException;

	List<VoucherRequest> getAllVouchersByCandidateEmail(String candidateEmail) throws NotFoundException;
	
	
	VoucherRequest updateExamDate(String voucherCode, LocalDate newExamDate) throws NotFoundException;
	
	 VoucherRequest updateExamResult(String voucherCode, String newExamResult) throws NotFoundException;

}