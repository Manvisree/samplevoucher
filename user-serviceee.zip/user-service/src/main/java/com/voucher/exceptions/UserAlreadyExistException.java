package com.voucher.exceptions;

public class UserAlreadyExistException extends Exception{

	public UserAlreadyExistException(){
		
	}
}
