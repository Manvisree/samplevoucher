package com.voucher.exceptions;

public class ResourceAlreadyExistException extends Exception{
	
	public ResourceAlreadyExistException(String msg)
	{
		super(msg);
	}

}
